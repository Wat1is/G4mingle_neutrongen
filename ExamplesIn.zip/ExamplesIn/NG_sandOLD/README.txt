Vytvořeno pro simulace pro T. Czakoje do článku.
Vytvářeno od 28.6.2021.